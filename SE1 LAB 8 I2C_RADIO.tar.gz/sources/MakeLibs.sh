cd Utils
make lib
cd ..

cd GPIO
make lib
cd ..

cd PLL
make lib
cd ..

cd SCLK
make lib
cd ..

cd RTC
make lib
cd ..

cd LCD
make lib
cd ..

cd I2C
make lib
cd ..

cd Buttons
make lib
cd ..
