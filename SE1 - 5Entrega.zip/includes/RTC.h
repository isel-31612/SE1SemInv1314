#ifndef _RTC_H
#define _RTC_H

#include "LPC2106REG.h"
#include "PLL.h"

#define CLK_FREQ 32768

void RTC_Init();
void RTC_SetTime(int hour, int min, int sec);
void RTC_SetDate(int day, int mount, int year);
void RTC_SetDays(int dayWeek, int dayYear);

unsigned int getTime0();
unsigned int getTime1();
unsigned int getTime2();

#endif
