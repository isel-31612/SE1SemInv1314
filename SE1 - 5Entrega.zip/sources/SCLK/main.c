#include "../../includes/SClk.h"

void delay(unsigned int ticks)
{
	unsigned int start = SYSCLK_GetValue();
	while(1)
	{
		/* Espera activa */
		if(SYSCLK_Elapsed(start+ticks)>0)
			return;
	}
}

int main(){
	unsigned int DELAYTIME = 250;
	SYSCLK_Init(1000);		/* Acertar o clock do TIMER*/
	LedInit(0);				/* Funcao de iniciar o LED 0 = Desligado */
	while(1){
		delay(DELAYTIME);	/* Função para esperar X milissegundos */
		LedSetState(1);		/* Função para ligar o LED */
		delay(DELAYTIME);	/* Função para esperar X milissegundos */
		LedSetState(0);		/* Função para desligar o LED */
							/* Para que serve o LedGetState? */
	}

return 0;
}
