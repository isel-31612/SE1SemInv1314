#include "../../LCD.h"

void LCD_Init(void)
{
	GPIO_INIT(MASK_BIT_LCD);
	//INIT SYSCLK
	
	GPIO_WriteMask(MASK_BIT_LCD, 0x03);
	delay(5);
	
	GPIO_WriteMask(MASK_BIT_LCD, 0x03);
	delay(1);	
	
	GPIO_WriteMask(MASK_BIT_LCD, 0x03);
	
	GPIO_WriteMask(MASK_BIT_LCD, 0x02);
	
	GPIO_WriteMask(MASK_BIT_LCD, 0x02);
	GPIO_WriteMask(MASK_BIT_LCD, 0x08);//N = 1 e F = 0 * *
	
	GPIO_WriteMask(MASK_BIT_LCD, 0x00);
	GPIO_WriteMask(MASK_BIT_LCD, 0x80);
	
	GPIO_WriteMask(MASK_BIT_LCD, 0x00);
	GPIO_WriteMask(MASK_BIT_LCD, 0x01);
	
	GPIO_WriteMask(MASK_BIT_LCD, 0x00);
	GPIO_WriteMask(MASK_BIT_LCD, 0x06); /* I/D = 1 S = 0*/ 
}

void LCD_WriteChar(char ch)
{
	GPIO_WriteMask(MASK_BIT_LCD, 0x20 | (ch & MASK_HIGH));
	GPIO_WriteMask(MASK_BIT_LCD, 0x20 | (ch & MASK_LOW));
}

void LCD_WriteString(char *str)
{
	while(str != '\0')
	{
		LCD_WriteChar(str++);
	}
}

void LCD_Goto(int x, int y)
{

}

void LCD_Clear(void)
{

}