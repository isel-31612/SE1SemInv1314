#include "../../includes/RTC.h"

int main()
{
	unsigned int var;
	RTC_Init();
	
	while(1)
	{
		var = getTime0();
	}
	
	return 0;
}
