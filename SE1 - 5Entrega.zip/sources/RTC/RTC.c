#include "../../includes/RTC.h"

void RTC_Init()
{
	RTC->CCR = 0x2; // desactiva os contadores e faz reset aos counter do rtc
	RTC_CLOCK->PREINT = (getPclk() / CLK_FREQ) -1;
	RTC_CLOCK->PREFRAC = getPclk() -((RTC_CLOCK->PREINT +1) * CLK_FREQ);
	
	RTC->ILR = 0x3;
	RTC->ILR = 0x0;
	
	RTC->CIIR = 0x0;
	RTC->AMR = 0xFF;
	
	RTC_SetTime(14,20,00);
	RTC_SetDate(8,11,2013);
	RTC_SetDays(5 ,365);
	
	RTC->CCR = 0x1;
	
}

void RTC_SetTime(int hour, int min, int sec)
{
	RTC->HOUR = hour;
	RTC->MIN = min;
	RTC->SEC = sec;
}

void RTC_SetDate(int day, int month, int year)
{
	RTC->DOM = day;
	RTC->MONTH = month;
	RTC->YEAR = year;
}

void RTC_SetDays(int dayWeek, int dayYear)
{
	RTC->DOW = dayWeek;
	RTC->DOY = dayYear;
}

unsigned int getTime0()
{
	return RTC->CTIME0;
}

unsigned int getTime1()
{
	return RTC->CTIME1;
}

unsigned int getTime2()
{
	return RTC->CTIME2;
}
