#include "GPIO.h"

void GPIO_Init(unsigned int outbitmask)
{
	GPIO->DIR=outbitmask;
}

void GPIO_SetDirection(unsigned int outbit,unsigned int mask )
{
	GPIO->DIR=(GPIO->DIR&~mask) | (outbit&mask);
}
	
unsigned int GPIO_Read()
{
	return GPIO->PIN;
}

void GPIO_Write(unsigned int value)
{
	GPIO_Clr(0xFFFFFF);
	GPIO_Set(value);
}
void GPIO_Set(unsigned int maskbit)
{
	GPIO->SET=maskbit;
}
void GPIO_Clr(unsigned int maskbit)
{
	GPIO->CLR=maskbit;
}
