#include "GPIO.h"

int main()
{
	GPIO_Init(0x000F);
}
