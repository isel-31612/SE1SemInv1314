#ifndef _UTILS_H_
#define _UTILS_H_

int divide(int,int);
int resto(int,int);

#endif


