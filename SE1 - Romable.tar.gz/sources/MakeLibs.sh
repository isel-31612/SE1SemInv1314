cd Utils
make lib
cd ..

cd GPIO
make lib
cd ..

cd PLL
make lib
cd ..

cd SCLK
make lib
cd ..

cd RTC
make lib
cd ..

cd LCD
make lib
cd ..
